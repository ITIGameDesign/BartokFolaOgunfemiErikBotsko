# Bartok-base
Gibson's Prospector Solitaire (Gliozzi build)
